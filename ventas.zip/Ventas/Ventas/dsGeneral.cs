﻿namespace Ventas {
    
    
    public partial class dsGeneral {
    }
}

namespace Ventas.dsGeneralTableAdapters {
    partial class taProducto
    {
    }


    public partial class taEmpleadoo
    {
    }
}
